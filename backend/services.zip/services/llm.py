"""
EduGenAI - Hybrid LLM Service

Groq is the lesson director.

The LLM returns:
- complete lesson
- 5-7 scenes for beginner mode
- 10-16 second narration per scene
- content_type:
    rich     -> real image + animated annotations
    process  -> Manim equations/process diagrams
    narrative -> image-based scene
- actions for Manim
- image_keywords for real visual search
"""

import json
import logging

from groq import AsyncGroq

from config import GROQ_API_KEY

logger = logging.getLogger(__name__)

client = AsyncGroq(
    api_key=GROQ_API_KEY
)

MODEL_NAME = "openai/gpt-oss-120b"


SCENE_SYSTEM_PROMPT = r"""
You are EduGenAI's expert teacher, lesson planner and storyboard director.

The user may enter only a topic such as:
"Photosynthesis"

You must understand the topic and create a complete educational lesson.
The lesson must feel like a teacher explaining the subject from beginning
to end, not like unrelated AI-generated clips.

LEARNING MODES:

BASIC:
- Grade 5-6 language.
- 5-6 scenes.
- Simple explanations and examples.
- Total lesson approximately 60-75 seconds.

BEGINNER:
- Grade 8-9 language.
- 6-7 scenes.
- Clear logical progression.
- Important terminology explained simply.
- Total lesson approximately 75-100 seconds.

ADVANCED:
- Technical but understandable.
- 7-9 scenes.
- Include mechanisms, relationships and important details.
- Total lesson approximately 90-120 seconds.

CONTENT TYPE:

Use "rich" when the topic is best explained using real-world imagery
plus annotations:
- photosynthesis
- human heart
- digestive system
- water cycle
- solar system
- volcano
- cell
- DNA
- ecosystems
- anatomy
- geography

Use "process" when the important thing is movement, equations,
mathematical relationships, algorithms, circuits, transformations or
abstract mechanisms that are better drawn with Manim.

Use "narrative" for people, history, places, organizations and events.

For science topics with a recognizable real-world subject, prefer "rich".
For equations and mathematical/scientific formulas, use "process" for
the scenes where the equation itself must be animated.

IMPORTANT:
A single lesson may contain both real-world visuals and equations.
Set top-level content_type to "rich" for a mainly real-world science lesson.
For individual scenes, use:
- "scene_visual_type": "image"
- "scene_visual_type": "manim"
- "scene_visual_type": "image+manim"

RENDERING RULES:

1. Every scene must teach ONE meaningful idea.
2. Scene order must be logically connected.
3. Do not pad the video with empty narration.
4. Narration should normally be 20-35 words per scene.
5. Duration should normally be 10-16 seconds.
6. visual_description must explain exactly what the student should see.
7. For image scenes, provide 2-5 useful image search keywords.
8. For Manim scenes, provide concrete actions using simple objects.
9. If an equation is important, put the equation in an "equation" field.
10. Never ask an image search provider to create scientific diagrams.
11. Never put long text inside an AI image.
12. Use Manim for equations, arrows, molecule movement and step diagrams.
13. Use real images for recognizable physical subjects.
14. Do not create a talking presenter in every scene.
15. The talking avatar is an optional teaching presenter, not the main visual.
16. Return ONLY valid JSON.
"""


SCENE_USER_PROMPT = r"""
TOPIC / SOURCE CONTENT:
{content}

TARGET LANGUAGE:
{language}

LEARNING MODE:
{learning_mode}

Return this exact JSON structure:

{{
  "title": "Clear educational title",
  "subject": "Subject area",
  "learning_mode": "{learning_mode}",
  "content_type": "rich",
  "total_scenes": 7,
  "scenes": [
    {{
      "scene_id": 1,
      "title": "Scene title",
      "narration": "Natural teacher narration, approximately 20-35 words.",
      "visual_description": "Exactly what the viewer should see and what changes during this scene.",
      "scene_visual_type": "image|manim|image+manim",
      "emotion": "neutral|curious|excited|serious|calm|surprised",
      "duration_seconds": 12,
      "key_concepts": ["concept1", "concept2"],
      "background_color": "#102030",

      "image_keywords": [
        "specific visual search phrase",
        "another useful phrase"
      ],

      "actions": [
        {{
          "object": "sunlight",
          "action": "move_to",
          "target": "leaf"
        }}
      ],

      "equation": "",
      "manim_visual": "Describe the exact equation/process animation if this scene uses Manim."
    }}
  ],

  "summary": "Two or three sentences summarizing the lesson."
}}

ACTION RULES:
- For image scenes: actions=[] and equation="".
- For Manim scenes: image_keywords=[].
- Use simple objects such as leaf, sun, water, CO2, arrow, glucose,
  circle, molecule, root, stem.
- Allowed actions:
  appear, fade_in, move_to, move_up, move_down, rotate,
  scale_up, scale_down, disappear, transform_into.
- If scene_visual_type is image+manim, both image_keywords and actions
  may be populated.

For "Photosynthesis", a good logical progression is:
1. What photosynthesis is
2. Sunlight and chlorophyll
3. Water absorbed by roots
4. Carbon dioxide entering leaves
5. What happens inside chloroplasts
6. Glucose and oxygen production
7. Overall equation and summary

Do not blindly use that sequence for unrelated topics; reason about the
actual topic.
"""


async def generate_scenes(
    content: str,
    language: str = "English",
    learning_mode: str = "beginner",
) -> dict:

    mode = (
        learning_mode
        .lower()
        .strip()
    )

    if mode not in (
        "basic",
        "beginner",
        "advanced",
    ):
        mode = "beginner"

    content = str(
        content or ""
    ).strip()

    if not content:
        raise RuntimeError(
            "No educational topic/content was provided."
        )

    # Keep enough source material for a real lesson.
    content = content[:8000]

    response = await client.chat.completions.create(
        model=MODEL_NAME,
        messages=[
            {
                "role": "system",
                "content": SCENE_SYSTEM_PROMPT,
            },
            {
                "role": "user",
                "content": SCENE_USER_PROMPT.format(
                    content=content,
                    language=language,
                    learning_mode=mode,
                ),
            },
        ],
        response_format={
            "type": "json_object"
        },
        temperature=0.55,
    )

    data = json.loads(
        response.choices[0]
        .message.content
        .strip()
    )

    data["learning_mode"] = mode

    scenes = data.get(
        "scenes",
        [],
    )

    if not scenes:
        raise RuntimeError(
            "Groq returned no scenes."
        )

    for i, scene in enumerate(
        scenes
    ):

        scene["scene_id"] = i + 1

        scene.setdefault(
            "title",
            f"Scene {i + 1}",
        )

        scene.setdefault(
            "narration",
            "",
        )

        scene.setdefault(
            "visual_description",
            scene["narration"],
        )

        scene.setdefault(
            "emotion",
            "neutral",
        )

        scene.setdefault(
            "duration_seconds",
            12,
        )

        scene.setdefault(
            "key_concepts",
            [],
        )

        scene.setdefault(
            "image_keywords",
            [],
        )

        scene.setdefault(
            "actions",
            [],
        )

        scene.setdefault(
            "equation",
            "",
        )

        scene.setdefault(
            "manim_visual",
            "",
        )

        scene.setdefault(
            "scene_visual_type",
            "image",
        )

        # Keep rendering times realistic.
        try:
            d = float(
                scene["duration_seconds"]
            )
        except Exception:
            d = 12.0

        scene["duration_seconds"] = max(
            8,
            min(
                int(round(d)),
                20,
            ),
        )

    data["total_scenes"] = len(
        scenes
    )

    logger.info(
        "Generated %d scenes [%s / %s] for %s",
        len(scenes),
        mode,
        data.get(
            "content_type",
            "rich",
        ),
        data.get(
            "title",
            "Untitled",
        ),
    )

    return data


# ------------------------------------------------------------
# Quiz
# ------------------------------------------------------------

QUIZ_SYSTEM_PROMPT = r"""
You are an expert educational assessment designer.

Create MCQs from the provided educational content.

Rules:
- exactly 4 options
- exactly one correct answer
- test understanding
- include easy, medium and hard when appropriate
- provide a short explanation
- use the requested language
- return ONLY valid JSON
"""

QUIZ_USER_PROMPT = r"""
CONTENT:
{content}

DIFFICULTY:
{difficulty}

NUMBER OF QUESTIONS:
{num_questions}

LANGUAGE:
{language}

Return:

{{
  "quiz_title": "Quiz title",
  "total_questions": {num_questions},
  "questions": [
    {{
      "id": 1,
      "question": "Question",
      "options": [
        "A) option 1",
        "B) option 2",
        "C) option 3",
        "D) option 4"
      ],
      "correct_answer": "A",
      "difficulty": "easy",
      "explanation": "Explanation",
      "concept_tested": "Concept"
    }}
  ]
}}
"""


async def generate_quiz(
    content: str,
    num_questions: int = 5,
    difficulty: str = "medium",
    language: str = "English",
) -> dict:

    response = await client.chat.completions.create(
        model=MODEL_NAME,
        messages=[
            {
                "role": "system",
                "content": QUIZ_SYSTEM_PROMPT,
            },
            {
                "role": "user",
                "content": QUIZ_USER_PROMPT.format(
                    content=content,
                    num_questions=num_questions,
                    difficulty=difficulty,
                    language=language,
                ),
            },
        ],
        response_format={
            "type": "json_object"
        },
        temperature=0.6,
    )

    return json.loads(
        response.choices[0]
        .message.content
        .strip()
    )


# ------------------------------------------------------------
# Tutor
# ------------------------------------------------------------

TUTOR_SYSTEM_PROMPT = r"""
You are EduBot, a friendly educational tutor.

Explain concepts step by step.
Use simple analogies and examples.
Use the Socratic method when useful.
Be encouraging.
Respond in {language}.

Lesson context:
{context}

Difficulty:
{difficulty}

Weak areas:
{weak_areas}
"""


async def tutor_chat(
    message: str,
    context: str,
    chat_history: list[dict] = None,
    difficulty: str = "medium",
    weak_areas: str = "none identified yet",
    language: str = "English",
) -> str:

    messages = [
        {
            "role": "system",
            "content": TUTOR_SYSTEM_PROMPT.format(
                context=context[:5000],
                difficulty=difficulty,
                weak_areas=weak_areas,
                language=language,
            ),
        }
    ]

    for msg in (
        chat_history or []
    )[-10:]:

        messages.append(
            {
                "role": msg["role"],
                "content": msg["content"],
            }
        )

    messages.append(
        {
            "role": "user",
            "content": message,
        }
    )

    response = await client.chat.completions.create(
        model=MODEL_NAME,
        messages=messages,
        temperature=0.65,
    )

    return (
        response.choices[0]
        .message.content
        .strip()
    )


# ------------------------------------------------------------
# Rich visual layout
# ------------------------------------------------------------

RICH_LAYOUT_SYSTEM_PROMPT = r"""
You are an educational visual designer.

Create a clean annotated visual layout for a science lesson.

Rules:
- topic_title: maximum 3 words, uppercase
- topic_subtitle: one short sentence
- background_search_query: specific real-world image search phrase
- annotations: 4-6 useful labels
- process_steps: 4-6 steps
- inset_panel: useful close-up/detail image
- chapter_tabs: 3-5 short chapters
- labels must describe real concepts from the lesson
- never invent irrelevant objects
- return ONLY JSON
"""

RICH_LAYOUT_USER_PROMPT = r"""
TOPIC:
{topic}

SUBJECT:
{subject}

SCENE NARRATIONS:
{narrations}

Return:

{{
  "topic_title": "TOPIC",
  "topic_subtitle": "One short sentence.",
  "background_search_query": "specific real-world educational photo search",
  "annotations": [
    {{
      "label": "SUNLIGHT",
      "sublabel": "Light provides energy.",
      "position": "top-left",
      "arrow_to": "center-top"
    }}
  ],
  "process_steps": [
    "First step",
    "Second step",
    "Third step",
    "Fourth step"
  ],
  "inset_panel": {{
    "title": "DETAIL VIEW",
    "image_query": "specific close-up search",
    "labels": ["label1", "label2"]
  }},
  "chapter_tabs": [
    "Overview",
    "Inputs",
    "Process",
    "Products"
  ]
}}
"""


async def generate_rich_layout(
    scenes: dict,
) -> dict:

    topic = scenes.get(
        "title",
        "Educational Topic",
    )

    subject = scenes.get(
        "subject",
        "Science",
    )

    narrations = "\n".join(
        f"Scene {s.get('scene_id', i + 1)}: "
        f"{s.get('narration', '')}"
        for i, s in enumerate(
            scenes.get(
                "scenes",
                [],
            )[:7]
        )
    )

    try:

        response = await client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {
                    "role": "system",
                    "content": RICH_LAYOUT_SYSTEM_PROMPT,
                },
                {
                    "role": "user",
                    "content": RICH_LAYOUT_USER_PROMPT.format(
                        topic=topic,
                        subject=subject,
                        narrations=narrations,
                    ),
                },
            ],
            response_format={
                "type": "json_object"
            },
            temperature=0.4,
        )

        return json.loads(
            response.choices[0]
            .message.content
            .strip()
        )

    except Exception as exc:

        logger.warning(
            "Rich layout generation failed: %s",
            exc,
        )

        return {
            "topic_title": str(
                topic
            ).upper()[:20],
            "topic_subtitle": (
                f"Learn about {topic}."
            ),
            "background_search_query": (
                f"{topic} educational science"
            ),
            "annotations": [],
            "process_steps": [],
            "inset_panel": {
                "title": "",
                "image_query": "",
                "labels": [],
            },
            "chapter_tabs": [
                "Overview"
            ],
        }
