"""
EduGenAI - HYBRID Educational Video Renderer

Fast local/cloud-free-first design:
    Groq -> lesson/storyboard
    image_fetcher -> relevant visual per scene
    Manim -> equations/process diagrams
    TTS -> narration
    SRT -> subtitles
    FFmpeg -> final MP4

This intentionally does NOT use slow cloud text-to-video.
"""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
import tempfile
import time
import uuid
from pathlib import Path

from config import VIDEO_DIR

logger = logging.getLogger(__name__)

WIDTH = 1280
HEIGHT = 720
FPS = 12


def _run(cmd: list[str], timeout: int = 300) -> None:
    subprocess.run(cmd, check=True, timeout=timeout)


def _srt_timestamp(seconds: float) -> str:
    ms = int(max(0, seconds) * 1000)
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _write_master_srt(scenes: list[dict], path: str) -> None:
    """
    Create subtitles directly from the narration that TTS already uses.
    This guarantees subtitles are available even if the separate subtitle
    service fails.
    """
    current = 0.0
    entry = 1

    with open(path, "w", encoding="utf-8", newline="\n") as f:
        for scene in scenes:
            text = str(scene.get("narration", "")).strip()
            if not text:
                continue

            try:
                duration = float(
                    scene.get(
                        "audio_duration",
                        scene.get("duration_seconds", 10),
                    )
                )
            except Exception:
                duration = 10.0

            duration = max(0.5, duration)

            words = text.split()
            chunk_size = 11
            chunks = [
                " ".join(words[i:i + chunk_size])
                for i in range(0, len(words), chunk_size)
            ] or [text]

            chunk_duration = duration / len(chunks)

            for i, chunk in enumerate(chunks):
                start = current + i * chunk_duration
                end = current + (i + 1) * chunk_duration

                f.write(f"{entry}\n")
                f.write(
                    f"{_srt_timestamp(start)} --> "
                    f"{_srt_timestamp(end)}\n"
                )
                f.write(chunk + "\n\n")
                entry += 1

            current += duration


def _escape_subtitle_path(path: str) -> str:
    p = os.path.abspath(path).replace("\\", "/")
    p = p.replace(":", r"\:")
    p = p.replace("'", r"\'")
    return p


def _burn_subtitles(
    input_path: str,
    srt_path: str,
    output_path: str,
) -> None:
    safe = _escape_subtitle_path(srt_path)

    vf = (
        f"subtitles='{safe}':force_style="
        "'FontName=Arial,FontSize=20,"
        "PrimaryColour=&H00FFFFFF,"
        "OutlineColour=&H00000000,"
        "BackColour=&H90000000,"
        "BorderStyle=3,Outline=1,"
        "Shadow=0,MarginV=24'"
    )

    _run(
        [
            "ffmpeg", "-y", "-loglevel", "error",
            "-i", input_path,
            "-vf", vf,
            "-c:v", "libx264",
            "-preset", "veryfast",
            "-crf", "20",
            "-pix_fmt", "yuv420p",
            "-c:a", "copy",
            "-movflags", "+faststart",
            output_path,
        ],
        timeout=600,
    )


def _mux_audio(
    video_path: str,
    audio_path: str | None,
    output_path: str,
) -> None:
    cmd = [
        "ffmpeg", "-y", "-loglevel", "error",
        "-i", video_path,
    ]

    if audio_path and os.path.exists(audio_path):
        cmd += [
            "-i", audio_path,
            "-map", "0:v:0",
            "-map", "1:a:0",
            "-c:a", "aac",
            "-b:a", "128k",
            "-shortest",
        ]
    else:
        cmd += [
            "-map", "0:v:0",
            "-an",
        ]

    cmd += [
        "-c:v", "libx264",
        "-preset", "veryfast",
        "-crf", "20",
        "-pix_fmt", "yuv420p",
        "-movflags", "+faststart",
        output_path,
    ]

    _run(cmd, timeout=300)


async def _render_manim(
    scene_list: list[dict],
    output_path: Path,
) -> dict:
    """
    Use Manim only for process/equation/diagram scenes.
    """

    from services.manim_renderer import render_process_scene

    temp = tempfile.mkdtemp(prefix="edugen_manim_")

    try:
        semaphore = asyncio.Semaphore(3)

        async def render_one(index: int, scene: dict):
            async with semaphore:
                try:
                    return index, await render_process_scene(
                        scene, index
                    )
                except Exception as exc:
                    logger.exception(
                        "Manim scene %d failed: %s",
                        index + 1,
                        exc,
                    )
                    return index, None

        results = await asyncio.gather(
            *[
                render_one(i, s)
                for i, s in enumerate(scene_list)
            ]
        )
        results.sort(key=lambda x: x[0])

        rendered = [
            (i, p)
            for i, p in results
            if p
        ]

        if not rendered:
            raise RuntimeError(
                "Manim could not render any process scenes."
            )

        scene_mp4s = []

        for index, manim_path in rendered:
            scene = scene_list[index]
            audio_path = scene.get("audio_path")

            try:
                duration = float(
                    scene.get(
                        "audio_duration",
                        scene.get("duration_seconds", 10),
                    )
                )
            except Exception:
                duration = 10.0

            normalized = os.path.join(
                temp,
                f"scene_{index:03d}.mp4",
            )

            _mux_audio(
                str(manim_path),
                str(audio_path) if audio_path else None,
                normalized,
            )

            scene_mp4s.append(
                (index, normalized)
            )

        scene_mp4s.sort(key=lambda x: x[0])

        concat_file = os.path.join(
            temp,
            "concat.txt",
        )

        with open(
            concat_file,
            "w",
            encoding="utf-8",
        ) as f:
            for _, path in scene_mp4s:
                safe = (
                    os.path.abspath(path)
                    .replace("\\", "/")
                    .replace("'", "'\\''")
                )
                f.write(f"file '{safe}'\n")

        _run(
            [
                "ffmpeg", "-y", "-loglevel", "error",
                "-f", "concat",
                "-safe", "0",
                "-i", concat_file,
                "-c", "copy",
                str(output_path),
            ],
            timeout=600,
        )

        return {
            "video_path": str(output_path),
            "renderer": "manim",
            "total_scenes": len(scene_mp4s),
        }

    finally:
        shutil.rmtree(temp, ignore_errors=True)


async def _render_rich(
    scenes: dict,
    output_filename: str,
) -> dict:
    """
    Use the existing rich renderer.

    It fetches a different relevant image per scene and adds:
    annotations, process indicators, camera-like movement and the teacher
    asset. This is much faster than text-to-video generation.
    """
    from services import rich_renderer_dynamic

    return await rich_renderer_dynamic.generate_rich_video(
        scenes,
        output_filename,
        scenes.get("language", "en"),
    )


async def generate_video(
    scenes: dict,
    output_filename: str = None,
    lang_code: str = "en",
) -> dict:
    """
    Main video entry point used by routes.generate.

    Routing:
        process -> Manim
        rich/narrative -> real-image rich renderer

    Voice and subtitles are ALWAYS added/verified here.
    """

    start = time.time()

    scene_list = scenes.get("scenes", [])

    if not scene_list:
        raise RuntimeError(
            "No scenes were generated."
        )

    if not output_filename:
        output_filename = (
            f"edugen_{uuid.uuid4().hex[:8]}.mp4"
        )

    VIDEO_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    final_path = (
        VIDEO_DIR / output_filename
    )

    scenes["language"] = lang_code

    content_type = str(
        scenes.get(
            "content_type",
            "rich",
        )
    ).lower().strip()

    # ----------------------------------------------------------
    # Generate visuals
    # ----------------------------------------------------------

    if content_type == "process":
        logger.info(
            "🎨 PROCESS VIDEO: Manim"
        )

        await _render_manim(
            scene_list,
            final_path,
        )

        renderer = "manim"

    else:
        logger.info(
            "🖼️ RICH VIDEO: image_fetcher + animation"
        )

        result = await _render_rich(
            scenes,
            output_filename,
        )

        rich_path = Path(
            result["video_path"]
        )

        if rich_path.exists():
            if rich_path.resolve() != final_path.resolve():
                shutil.copy2(
                    rich_path,
                    final_path,
                )

        renderer = "rich"

    if not final_path.exists():
        raise RuntimeError(
            "Video renderer did not create an MP4."
        )

    # ----------------------------------------------------------
    # Make sure audio exists.
    # ----------------------------------------------------------

    probe = subprocess.run(
        [
            "ffprobe",
            "-v", "error",
            "-select_streams", "a:0",
            "-show_entries", "stream=index",
            "-of", "csv=p=0",
            str(final_path),
        ],
        capture_output=True,
        text=True,
    )

    has_audio = bool(
        probe.stdout.strip()
    )

    if not has_audio:

        logger.warning(
            "Video has no audio. Rebuilding audio track from scene TTS."
        )

        audio_files = [
            str(s["audio_path"])
            for s in scene_list
            if s.get("audio_path")
            and os.path.exists(
                str(s["audio_path"])
            )
        ]

        if audio_files:

            temp = tempfile.mkdtemp(
                prefix="edugen_audio_"
            )

            try:
                audio_list = os.path.join(
                    temp,
                    "audio.txt",
                )

                with open(
                    audio_list,
                    "w",
                    encoding="utf-8",
                ) as f:
                    for p in audio_files:
                        safe = (
                            os.path.abspath(p)
                            .replace("\\", "/")
                            .replace("'", "'\\''")
                        )
                        f.write(
                            f"file '{safe}'\n"
                        )

                merged_audio = os.path.join(
                    temp,
                    "merged.m4a",
                )

                _run(
                    [
                        "ffmpeg", "-y",
                        "-loglevel", "error",
                        "-f", "concat",
                        "-safe", "0",
                        "-i", audio_list,
                        "-vn",
                        "-c:a", "aac",
                        "-b:a", "128k",
                        merged_audio,
                    ],
                    timeout=300,
                )

                muxed = str(
                    final_path
                ) + ".audio.mp4"

                _run(
                    [
                        "ffmpeg", "-y",
                        "-loglevel", "error",
                        "-i", str(final_path),
                        "-i", merged_audio,
                        "-map", "0:v:0",
                        "-map", "1:a:0",
                        "-c:v", "copy",
                        "-c:a", "aac",
                        "-b:a", "128k",
                        "-shortest",
                        muxed,
                    ],
                    timeout=300,
                )

                os.replace(
                    muxed,
                    final_path,
                )

            finally:
                shutil.rmtree(
                    temp,
                    ignore_errors=True,
                )

    # ----------------------------------------------------------
    # Burn subtitles into the FINAL video.
    # ----------------------------------------------------------

    temp = tempfile.mkdtemp(
        prefix="edugen_subtitles_"
    )

    try:
        srt_path = os.path.join(
            temp,
            "subtitles.srt",
        )

        _write_master_srt(
            scene_list,
            srt_path,
        )

        subtitled = str(
            final_path
        ) + ".subtitled.mp4"

        try:
            _burn_subtitles(
                str(final_path),
                srt_path,
                subtitled,
            )

            os.replace(
                subtitled,
                final_path,
            )

            subtitles_ok = True

        except Exception as exc:
            logger.exception(
                "Subtitle burn-in failed: %s",
                exc,
            )

            subtitles_ok = False

    finally:
        shutil.rmtree(
            temp,
            ignore_errors=True,
        )

    elapsed = time.time() - start

    total_duration = sum(
        float(
            s.get(
                "audio_duration",
                s.get(
                    "duration_seconds",
                    10,
                ),
            )
        )
        for s in scene_list
    )

    logger.info(
        "🎬 FINAL HYBRID VIDEO: %.1fs render, %.1fs content, %d scenes",
        elapsed,
        total_duration,
        len(scene_list),
    )

    return {
        "video_path": str(final_path),
        "filename": output_filename,
        "duration": round(total_duration, 1),
        "render_time_s": round(elapsed, 1),
        "resolution": f"{WIDTH}x{HEIGHT}",
        "fps": FPS,
        "total_scenes": len(scene_list),
        "renderer": renderer,
        "audio": has_audio,
        "subtitles": subtitles_ok,
    }


async def create_video(
    scenes: dict,
    output_filename: str = None,
    lang_code: str = "en",
) -> dict:
    return await generate_video(
        scenes,
        output_filename,
        lang_code,
    )
